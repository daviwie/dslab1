Reflect about your solution!

Summary:
- TODO